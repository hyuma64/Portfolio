Select * 
FROM DataCleaning.dbo.[Nashville Housing Data]
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--Populate Property Address Format

Select * 
FROM DataCleaning.dbo.[Nashville Housing Data]
--Where PropertyAddress is NULL
order by ParcelID

Select a.ParcelID, a.PropertyAddress, b.ParcelID, b.PropertyAddress, ISNULL(a.PropertyAddress,b.PropertyAddress) -- ISNULL checks to see if value is NULL, and if it is, it will populate with PropertyAdress
FROM DataCleaning.dbo.[Nashville Housing Data] a
JOIN DataCleaning.dbo.[Nashville Housing Data] b
	on a.ParcelID = b.ParcelID
	AND a.[UniqueID ] <> b.[UniqueID ]
WHERE a.PropertyAddress is NULL

Update a
SET PropertyAddress = ISNULL(a.PropertyAddress,b.PropertyAddress)
FROM DataCleaning.dbo.[Nashville Housing Data] a
JOIN DataCleaning.dbo.[Nashville Housing Data] b
	on a.ParcelID = b.ParcelID
	AND a.[UniqueID ] <> b.[UniqueID ]
WHERE a.PropertyAddress is NULL

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--Breaking out Address into Individual Columns (Address,City,State) 

Select PropertyAddress
FROM DataCleaning.dbo.[Nashville Housing Data]

SELECT
SUBSTRING(PropertyAddress, 1, CHARINDEX(',',PropertyAddress)-1) as Address  --CHARINDEX can search what position value lies on
, SUBSTRING(PropertyAddress,CHARINDEX(',',PropertyAddress)+1, LEN(PropertyAddress)) as Address
FROM DataCleaning.dbo.[Nashville Housing Data]

ALTER TABLE DataCleaning.dbo.[Nashville Housing Data]
Add PropertySplitAddress Nvarchar(255);

UPDATE DataCleaning.dbo.[Nashville Housing Data]
SET PropertySplitAddress = SUBSTRING(PropertyAddress, 1, CHARINDEX(',',PropertyAddress)-1) 

ALTER TABLE DataCleaning.dbo.[Nashville Housing Data]
Add PropertySplitCity Nvarchar(255);

UPDATE DataCleaning.dbo.[Nashville Housing Data]
SET PropertySplitCity = SUBSTRING(PropertyAddress,CHARINDEX(',',PropertyAddress)+1, LEN(PropertyAddress))

Select*
FROM DataCleaning.dbo.[Nashville Housing Data]

-- Separting OwnerAdress to address, city, state using PARSENAME
Select OwnerAddress
FROM DataCleaning.dbo.[Nashville Housing Data]

Select
PARSENAME(REPLACE(OwnerAddress,',','.'),3)
, PARSENAME(REPLACE(OwnerAddress,',','.'),2)
, PARSENAME(REPLACE(OwnerAddress,',','.'),1)
FROM DataCleaning.dbo.[Nashville Housing Data]

ALTER TABLE DataCleaning.dbo.[Nashville Housing Data]
Add OwnerSplitAddress Nvarchar(255);

UPDATE DataCleaning.dbo.[Nashville Housing Data]
SET OwnerSplitAddress = PARSENAME(REPLACE(OwnerAddress,',','.'),3) 

ALTER TABLE DataCleaning.dbo.[Nashville Housing Data]
Add OwnerSplitCity Nvarchar(255);

UPDATE DataCleaning.dbo.[Nashville Housing Data]
SET OwnerSplitCity = PARSENAME(REPLACE(OwnerAddress,',','.'),2)

ALTER TABLE DataCleaning.dbo.[Nashville Housing Data]
Add OwnerSplitState Nvarchar(255);

UPDATE DataCleaning.dbo.[Nashville Housing Data]
SET OwnerSplitState = PARSENAME(REPLACE(OwnerAddress,',','.'),1)

Select*
FROM DataCleaning.dbo.[Nashville Housing Data]

-------------------------------------------------------------------------------------------------------------------------------------------------------------------

--Change 1 and 0 to Yes and NO in "Sold as Vacant" field

Select Distinct(SoldAsVacant), Count(SoldAsVacant)
FROM DataCleaning.dbo.[Nashville Housing Data]
Group By SoldAsVacant
Order by 2

SELECT  SoldAsVacant,
	CASE WHEN SoldAsVacant = 1 THEN 'Yes' 
	WHEN SoldAsVacant = 0 THEN 'No'
	END
FROM DataCleaning.dbo.[Nashville Housing Data]

UPDATE DataCleaning.dbo.[Nashville Housing Data]
SET SoldAsVacant= CASE WHEN SoldAsVacant = 1 THEN 'Yes' 
	WHEN SoldAsVacant = 0 THEN 'No'
	END
FROM DataCleaning.dbo.[Nashville Housing Data]

--***Could not Converet 1 and 0 to yes/no  because varchar value cannot be changed to data type bit**--------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--Remove duplicates

WITH RowNumCTE AS(
SELECT *,
	ROW_NUMBER() OVER (
	PARTITION BY ParcelID,
				 PropertyAddress,
				 SalePrice,
				 SaleDate,
				 LegalReference
				 ORDER BY
					UniqueID
					) row_num


FROM DataCleaning.dbo.[Nashville Housing Data]
)
DELETE *
From RowNumCTE
Where row_num > 1

--------------------------------------------------------------------------------------------------------------------------------------------------------

-- Delete Unused Columns
		-- Use DROP COLUMN to delete any column you do not want from table. 

ALTER TABLE DataCleaning.dbo.[Nashville Housing Data]
DROP COLUMN OwnerAddress, TaxDistrict, PropertyAddress

ALTER TABLE DataCleaning.dbo.[Nashville Housing Data]
DROP COLUMN SaleDateConverted

Select*
FROM DataCleaning.dbo.[Nashville Housing Data]

